EASY_TUNNELER_PROD=1 GIN_MODE=release ./easy_tunneler
